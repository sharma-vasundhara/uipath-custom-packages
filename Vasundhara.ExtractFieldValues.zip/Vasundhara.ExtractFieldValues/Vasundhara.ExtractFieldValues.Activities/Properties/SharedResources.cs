﻿namespace UiPath.Shared.Localization
{
    class SharedResources : Vasundhara.ExtractFieldValues.Activities.Properties.Resources
    {
    }
}