using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using Vasundhara.ExtractFieldValues.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace Vasundhara.ExtractFieldValues.Activities
{
    [LocalizedDisplayName(nameof(Resources.ExtractFieldValues_DisplayName))]
    [LocalizedDescription(nameof(Resources.ExtractFieldValues_Description))]
    public class ExtractFieldValues : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.ExtractFieldValues_MainString_DisplayName))]
        [LocalizedDescription(nameof(Resources.ExtractFieldValues_MainString_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> MainString { get; set; }

        [LocalizedDisplayName(nameof(Resources.ExtractFieldValues_FieldNames_DisplayName))]
        [LocalizedDescription(nameof(Resources.ExtractFieldValues_FieldNames_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<String[]> FieldNames { get; set; }

        [LocalizedDisplayName(nameof(Resources.ExtractFieldValues_FieldValues_DisplayName))]
        [LocalizedDescription(nameof(Resources.ExtractFieldValues_FieldValues_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<String[]> FieldValues { get; set; }

        #endregion


        #region Constructors

        public ExtractFieldValues()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (MainString == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(MainString)));
            if (FieldNames == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(FieldNames)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var mainString = MainString.Get(context);
            var fieldNames = FieldNames.Get(context);

            ///////////////////////////
            // Add execution logic HERE
            ///////////////////////////

            // Preprocessing Input Data
            string low_mainString = mainString.ToLower();
            int len_fieldNames = fieldNames.Length;
            fieldNames = Array.ConvertAll<string, string>(fieldNames, delegate (string s) { return s.ToLower(); });

            // Output Array
            string[] out_fieldValues = new string[len_fieldNames];

            // Populating Output Array
            for (int i = 0; i < len_fieldNames; i++)
            {
                int temp_start_indx = low_mainString.IndexOf(fieldNames[i]) + fieldNames[i].Length + 1;
                if (i < (len_fieldNames - 1))
                {
                    int temp_len = low_mainString.IndexOf(fieldNames[i + 1]) - (low_mainString.IndexOf(fieldNames[i]) + fieldNames[i].Length + 1);
                    out_fieldValues[i] = mainString.Substring(temp_start_indx, temp_len).Trim();
                }
                else
                {
                    out_fieldValues[i] = mainString.Substring(temp_start_indx).Trim();
                }
            }

            // Outputs
            return (ctx) => {
                FieldValues.Set(ctx, out_fieldValues);
            };
        }
        #endregion
    }
}

