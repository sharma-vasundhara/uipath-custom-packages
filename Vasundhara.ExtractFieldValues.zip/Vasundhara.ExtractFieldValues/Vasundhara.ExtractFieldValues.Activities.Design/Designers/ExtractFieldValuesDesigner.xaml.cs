namespace Vasundhara.ExtractFieldValues.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for ExtractFieldValuesDesigner.xaml
    /// </summary>
    public partial class ExtractFieldValuesDesigner
    {
        public ExtractFieldValuesDesigner()
        {
            InitializeComponent();
        }
    }
}
