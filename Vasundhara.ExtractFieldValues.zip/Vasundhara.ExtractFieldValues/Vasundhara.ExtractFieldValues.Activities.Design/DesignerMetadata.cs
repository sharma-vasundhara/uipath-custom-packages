using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;
using Vasundhara.ExtractFieldValues.Activities.Design.Designers;
using Vasundhara.ExtractFieldValues.Activities.Design.Properties;

namespace Vasundhara.ExtractFieldValues.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute = new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(ExtractFieldValues), categoryAttribute);
            builder.AddCustomAttributes(typeof(ExtractFieldValues), new DesignerAttribute(typeof(ExtractFieldValuesDesigner)));
            builder.AddCustomAttributes(typeof(ExtractFieldValues), new HelpKeywordAttribute(""));


            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
