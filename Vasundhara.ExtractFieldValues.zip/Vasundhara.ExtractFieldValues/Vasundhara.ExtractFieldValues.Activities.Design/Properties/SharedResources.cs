﻿namespace UiPath.Shared.Localization
{
    class SharedResources : Vasundhara.ExtractFieldValues.Activities.Design.Properties.Resources
    {
    }
}